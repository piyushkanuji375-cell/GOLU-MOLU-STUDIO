package com.tripalstudio.app

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.OutputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioScreen() }
    }

    @Composable
    private fun StudioScreen() {
        var original by remember { mutableStateOf<Bitmap?>(null) }
        var brightness by remember { mutableFloatStateOf(0f) }
        var saturation by remember { mutableFloatStateOf(1f) }
        var warmth by remember { mutableFloatStateOf(0f) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) contentResolver.openInputStream(uri)?.use { original = BitmapFactory.decodeStream(it) }
        }
        val edited = remember(original, brightness, saturation, warmth) {
            original?.let { source ->
                val out = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(out)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                val cm = ColorMatrix().apply { setSaturation(saturation) }
                val m = cm.array
                m[4] += brightness * 255f + warmth * 35f
                m[9] += brightness * 255f
                m[14] += brightness * 255f - warmth * 35f
                paint.colorFilter = ColorMatrixColorFilter(cm)
                canvas.drawBitmap(source, 0f, 0f, paint)
                out
            }
        }
        MaterialTheme(colorScheme = darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFFFFB300), background = androidx.compose.ui.graphics.Color(0xFF101114), surface = androidx.compose.ui.graphics.Color(0xFF1B1D22))) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("TRIPAL STUDIO", fontSize = 27.sp, color = MaterialTheme.colorScheme.primary)
                Text("Your personal photo studio", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(20.dp))
                Button(onClick = { picker.launch("image/*") }) { Text("Choose Photo") }
                Spacer(Modifier.height(16.dp))
                if (edited != null) Image(edited.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 420.dp))
                else Text("Choose a photo to start editing", modifier = Modifier.padding(40.dp))
                Spacer(Modifier.height(18.dp))
                Text("Brightness ${(brightness * 100).toInt()}")
                Slider(value = brightness, onValueChange = { brightness = it }, valueRange = -0.5f..0.5f)
                Text("Color / Saturation ${(saturation * 100).toInt()}%")
                Slider(value = saturation, onValueChange = { saturation = it }, valueRange = 0f..2f)
                Text("Warmth ${(warmth * 100).toInt()}")
                Slider(value = warmth, onValueChange = { warmth = it }, valueRange = -1f..1f)
                Button(enabled = edited != null, onClick = { edited?.let { saveBitmap(it) } }) { Text("Save to Gallery") }
                Spacer(Modifier.height(10.dp))
                Text("AI enhancement: coming in a future update", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    private fun saveBitmap(bitmap: Bitmap) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "TripalStudio_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/TripalStudio")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            val stream: OutputStream? = contentResolver.openOutputStream(uri)
            stream?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            Toast.makeText(this, "Saved in Pictures/TripalStudio", Toast.LENGTH_LONG).show()
        } else Toast.makeText(this, "Could not save photo", Toast.LENGTH_LONG).show()
    }
}

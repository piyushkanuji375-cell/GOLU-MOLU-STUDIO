# TRIPAL STUDIO Android starter

A personal Android photo editor starter with photo picking, offline brightness/saturation/warmth adjustments, and gallery export.

## Build APK from a phone using GitHub Actions
1. Create a GitHub account and sign in at https://github.com.
2. Create a new **public** repository named `TRIPAL-STUDIO` (public repositories get the easiest GitHub Actions setup).
3. Upload the contents of this folder to the repository root (not the enclosing folder).
4. Open the repository's **Actions** tab and allow workflows if prompted.
5. Open **Build TRIPAL STUDIO APK** and tap **Run workflow** (or wait for the push build).
6. When the run is green, open it and download the `TRIPAL-STUDIO-APK` artifact. Extract the ZIP to get `app-debug.apk`.
7. Open the APK on Android and allow installation from that source if Android asks.

## Current scope
Offline editing is implemented. AI enhancement is not implemented yet; it needs a chosen cloud AI provider/API or an on-device model. Do not upload API keys into a public repository.
